import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'controllers/health_controller.dart';

class HealthScreen extends StatefulWidget {
  const HealthScreen({super.key});

  @override
  State<HealthScreen> createState() => _HealthScreenState();
}

class _HealthScreenState extends State<HealthScreen> {
  final HealthController controller = Get.put(HealthController());
  DateTime _focusedMonth = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;

    return Scaffold(
      backgroundColor: isDark ? Colors.black : const Color(0xFFF9F9F9),
      appBar: AppBar(
        title: Text(
          "Cycle Tracking",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: textColor,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: textColor),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildStatusCard(context),
            const SizedBox(height: 30),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.chevron_left),
                  onPressed: () => setState(
                    () => _focusedMonth = DateTime(
                      _focusedMonth.year,
                      _focusedMonth.month - 1,
                    ),
                  ),
                ),
                Text(
                  DateFormat('MMMM yyyy').format(_focusedMonth),
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.chevron_right),
                  onPressed: () => setState(
                    () => _focusedMonth = DateTime(
                      _focusedMonth.year,
                      _focusedMonth.month + 1,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            _buildCalendarGrid(),
            const SizedBox(height: 30),

            // DYNAMIC BUTTON
            Obx(() {
              bool isActive = controller.isPeriodActive;
              return SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isActive
                        ? Colors.grey.shade800
                        : Colors.redAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  onPressed: () => _showActionDialog(isActive),
                  child: Text(
                    isActive ? "Log Period Ended" : "Log Period Started",
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard(BuildContext context) {
    return Obx(() {
      bool isActive = controller.isPeriodActive;
      int daysUntil = controller.predictedNextPeriod.value
          .difference(DateTime.now())
          .inDays;

      String statusText;
      if (isActive) {
        int dayOfPeriod =
            DateTime.now().difference(controller.logs.first.startDate).inDays +
            1;
        statusText = "Period: Day $dayOfPeriod";
      } else {
        statusText = daysUntil > 0
            ? "$daysUntil Days until next period"
            : "Period might be late";
      }

      return Container(
        padding: const EdgeInsets.all(25),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isActive
                ? [Colors.pinkAccent.shade100, Colors.pink]
                : [Colors.redAccent.shade100, Colors.redAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(25),
          boxShadow: [
            BoxShadow(
              color: Colors.redAccent.withOpacity(0.3),
              blurRadius: 15,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Cycle Status",
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    statusText,
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    "Avg Cycle: ${controller.averageCycleLength.value} Days | Bleeding: ${controller.averageBleedLength.value} Days",
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: const BoxDecoration(
                color: Colors.white24,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.water_drop,
                color: Colors.white,
                size: 30,
              ),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildCalendarGrid() {
    int daysInMonth = DateTime(
      _focusedMonth.year,
      _focusedMonth.month + 1,
      0,
    ).day;
    int firstWeekday = DateTime(
      _focusedMonth.year,
      _focusedMonth.month,
      1,
    ).weekday;

    return Obx(
      () => GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 7,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
        ),
        itemCount: daysInMonth + (firstWeekday - 1),
        itemBuilder: (context, index) {
          if (index < firstWeekday - 1) return const SizedBox.shrink();

          final day = index - (firstWeekday - 1) + 1;
          final date = DateTime(_focusedMonth.year, _focusedMonth.month, day);

          bool isPeriod = controller.isPeriodDay(date);
          bool isPredicted = controller.isPredictedPeriodDay(date);
          bool isToday =
              date.day == DateTime.now().day &&
              date.month == DateTime.now().month &&
              date.year == DateTime.now().year;

          return GestureDetector(
            onTap: () {
              // NEW CALENDAR BEHAVIOR: Do not log on tap. Educate the user.
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    "Use the button below to log your period dates.",
                    style: GoogleFonts.poppins(),
                  ),
                  duration: const Duration(seconds: 2),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
            child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isPeriod
                    ? Colors.redAccent
                    : (isPredicted
                          ? Colors.pink.withOpacity(0.15)
                          : Colors.transparent),
                border: isToday
                    ? Border.all(color: Colors.redAccent, width: 2)
                    : (isPredicted
                          ? Border.all(
                              color: Colors.pinkAccent,
                              width: 1,
                              style: BorderStyle.solid,
                            )
                          : null),
                shape: BoxShape.circle,
              ),
              child: Text(
                "$day",
                style: TextStyle(
                  color: isPeriod
                      ? Colors.white
                      : (isPredicted
                            ? Colors.pinkAccent
                            : Theme.of(context).textTheme.bodyMedium?.color),
                  fontWeight: isPeriod || isToday || isPredicted
                      ? FontWeight.bold
                      : FontWeight.normal,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // THE YESTERDAY / TODAY DIALOG
  void _showActionDialog(bool isActive) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isActive ? "When did it end?" : "When did it start?",
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),

            // Option 1: TODAY
            ListTile(
              leading: const Icon(Icons.today, color: Colors.blue),
              title: Text(
                "Today",
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
              ),
              onTap: () {
                if (isActive)
                  controller.endPeriod(DateTime.now());
                else
                  controller.startPeriod(DateTime.now());
                Get.back();
              },
            ),
            const Divider(),

            // Option 2: YESTERDAY
            ListTile(
              leading: const Icon(Icons.history, color: Colors.orange),
              title: Text(
                "Yesterday",
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
              ),
              onTap: () {
                final yesterday = DateTime.now().subtract(
                  const Duration(days: 1),
                );
                if (isActive)
                  controller.endPeriod(yesterday);
                else
                  controller.startPeriod(yesterday);
                Get.back();
              },
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
