import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

// UPGRADED MODEL: Now handles Ranges instead of single days
class PeriodLog {
  DateTime startDate;
  DateTime? endDate; // Null means currently active
  bool isIgnored;

  PeriodLog({required this.startDate, this.endDate, this.isIgnored = false});

  factory PeriodLog.fromJson(Map<String, dynamic> json) => PeriodLog(
    startDate: DateTime.parse(json['startDate']),
    endDate: json['endDate'] != null ? DateTime.parse(json['endDate']) : null,
    isIgnored: json['isIgnored'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'startDate': startDate.toIso8601String(),
    'endDate': endDate?.toIso8601String(),
    'isIgnored': isIgnored,
  };
}

class HealthController extends GetxController {
  final storage = GetStorage();

  var logs = <PeriodLog>[].obs;
  var averageCycleLength = 28.obs;
  var averageBleedLength = 5.obs; // NEW: Learns how many days bleeding lasts
  var predictedNextPeriod = DateTime.now().obs;

  bool get isPeriodActive => logs.isNotEmpty && logs.first.endDate == null;

  @override
  void onInit() {
    super.onInit();
    var storedLogs = storage.read<List>('period_logs');
    if (storedLogs != null) {
      logs.assignAll(storedLogs.map((e) => PeriodLog.fromJson(e)).toList());
    }

    _runMathEngine();

    ever(logs, (_) {
      storage.write('period_logs', logs.map((e) => e.toJson()).toList());
      _runMathEngine();
      update(['calendar']); // Force Home Screen calendar to update
    });
  }

  // --- ACTIONS ---

  void startPeriod(DateTime date) {
    if (isPeriodActive) return; // Prevent double start

    // Check if Outlier (for Cycle length)
    if (logs.isNotEmpty) {
      final gap = date.difference(logs.first.startDate).inDays;
      if (gap < 21 || gap > 35) {
        logs.insert(0, PeriodLog(startDate: date, isIgnored: true));
        return;
      }
    }

    logs.insert(0, PeriodLog(startDate: date));
  }

  void endPeriod(DateTime date) {
    if (!isPeriodActive) return;

    // Ensure end date isn't BEFORE start date
    if (date.isBefore(logs.first.startDate)) {
      date = logs.first.startDate;
    }

    logs.first.endDate = date;
    logs.refresh(); // Triggers the 'ever' listener
  }

  // --- THE SMART MATH ENGINE ---

  void _runMathEngine() {
    if (logs.isEmpty) return;

    // 1. AUTO-CAP SECURITY (The > 7 Days Rule)
    if (isPeriodActive) {
      final daysActive = DateTime.now().difference(logs.first.startDate).inDays;
      if (daysActive > 7) {
        // Auto-close to 5 days
        logs.first.endDate = logs.first.startDate.add(
          const Duration(days: 4),
        ); // Day 0 to 4 = 5 days
      }
    }

    // 2. CALCULATE AVERAGE BLEED LENGTH
    List<int> bleedLengths = [];
    for (var log in logs) {
      if (log.endDate != null) {
        // +1 because Start: 1st, End: 5th = 5 days inclusive
        bleedLengths.add(log.endDate!.difference(log.startDate).inDays + 1);
      }
    }
    if (bleedLengths.isNotEmpty) {
      int sum = bleedLengths.reduce((a, b) => a + b);
      averageBleedLength.value = (sum / bleedLengths.length).round();
    } else {
      averageBleedLength.value = 5; // Default
    }

    // 3. CALCULATE AVERAGE CYCLE LENGTH (Weighted)
    if (logs.length >= 2) {
      List<int> cycleLengths = [];
      for (int i = 0; i < logs.length - 1; i++) {
        if (logs[i].isIgnored) continue;
        final gap = logs[i].startDate.difference(logs[i + 1].startDate).inDays;
        if (gap > 15 && gap < 60) cycleLengths.add(gap);
      }

      if (cycleLengths.isNotEmpty) {
        double weightedSum = 0;
        double totalWeight = 0;
        for (int i = 0; i < cycleLengths.length; i++) {
          double weight = (i == 0) ? 0.5 : (i == 1 ? 0.3 : 0.2);
          weightedSum += cycleLengths[i] * weight;
          totalWeight += weight;
        }
        averageCycleLength.value = (weightedSum / totalWeight).round();
      }
    }

    // 4. PREDICT NEXT PERIOD
    predictedNextPeriod.value = logs.first.startDate.add(
      Duration(days: averageCycleLength.value),
    );
  }

  // --- CALENDAR UI HELPERS ---

  bool isPeriodDay(DateTime date) {
    DateTime target = _normalize(date);
    for (var log in logs) {
      DateTime start = _normalize(log.startDate);
      DateTime end = log.endDate != null
          ? _normalize(log.endDate!)
          : _normalize(DateTime.now());

      if (target.isAfter(start.subtract(const Duration(days: 1))) &&
          target.isBefore(end.add(const Duration(days: 1)))) {
        return true;
      }
    }
    return false;
  }

  bool isPredictedPeriodDay(DateTime date) {
    if (logs.isEmpty || isPeriodDay(date)) return false;

    DateTime target = _normalize(date);
    DateTime predictStart = _normalize(predictedNextPeriod.value);
    DateTime predictEnd = predictStart.add(
      Duration(days: averageBleedLength.value - 1),
    );

    return target.isAfter(predictStart.subtract(const Duration(days: 1))) &&
        target.isBefore(predictEnd.add(const Duration(days: 1)));
  }

  DateTime _normalize(DateTime date) =>
      DateTime(date.year, date.month, date.day);
}
